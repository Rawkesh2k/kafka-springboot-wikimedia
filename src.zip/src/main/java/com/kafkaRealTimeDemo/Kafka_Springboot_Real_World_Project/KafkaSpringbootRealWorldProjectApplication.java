package com.kafkaRealTimeDemo.Kafka_Springboot_Real_World_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaSpringbootRealWorldProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaSpringbootRealWorldProjectApplication.class, args);
	}

}
