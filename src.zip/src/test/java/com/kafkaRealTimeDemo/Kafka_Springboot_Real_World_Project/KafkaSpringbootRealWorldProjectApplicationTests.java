package com.kafkaRealTimeDemo.Kafka_Springboot_Real_World_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSpringbootRealWorldProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
