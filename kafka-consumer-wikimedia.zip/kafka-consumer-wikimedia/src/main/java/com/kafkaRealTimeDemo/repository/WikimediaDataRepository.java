package com.kafkaRealTimeDemo.repository;

import com.kafkaRealTimeDemo.entity.WikimediaData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WikimediaDataRepository extends JpaRepository<WikimediaData, Long> {
}
