package com.kafkaRealTimeDemo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "wikimedia_recent_change")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WikimediaData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    //@Lob
    //This annotation is used to store large size of data(meaning each line of event data is like a paragraph)

    @Column(columnDefinition="LONGTEXT")
    private String wikiEventData;
}
